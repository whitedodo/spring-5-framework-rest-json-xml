package com.example.restweb.resources;

import com.example.restweb.model.FileInfo;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.jboss.resteasy.annotations.providers.multipart.MultipartForm;

@Path("/api")
public class MyResources
{
	// Index
	@GET
	@Path("")
    @Produces("application/json")
	public Response get()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("ok");
		
		return Response.status(200).entity(buf).build();
	}

    @GET
    @Path("users/{id}")
    @Produces("application/json")
    public Response getUserById(@PathParam("id") Integer id)
    {
        User user = new User();
        user.setId(id);
        user.setFirstName("Lokesh");
        user.setLastName("Gupta");
        
        return Response.status(200).entity(user).build();
    }
    
    @Path("foo/{param}-{other}")
	@PUT
    @Produces("application/json")
	public Response putFooParam(@PathParam("param") String param,
							  	@PathParam("other") String other)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("param").append("=").append(param).append(";");
		buf.append("other").append("=").append(other).append(";");
		
		return Response.status(200).entity(buf).build();
		
	}
    
	@Path("form")
	@POST
    @Produces("application/json")
	public String postForm(@FormParam("id") String a,
						   @FormParam("passwd") String b){
		
		return a +"/" +b;
		
	}

	@Path("lookup")
	@GET
    @Produces("application/json")
	public Response lookup(@QueryParam("id") String id,
			@Context UriInfo uriInfo)
	{

		StringBuffer buf = new StringBuffer();
		buf.append("param").append("=").append(id).append(";");
		
		return Response.status(200).entity(buf).build();
	}
	

    @POST
    @Path("/upload-file")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadFile(@MultipartForm FileInfo info) throws Exception {
    	
    	String fileName = info.getFileName();
    	
    	// RESTEasy는 한글 자체가 안됨.
    	
    	/*
    	form.setFileName(filename);
    	
    	System.out.println("파일명1:" + form.getFileName());
    	
        String fileName = form.getFileName() == null ? "Unknown" : form.getFileName() ;
        String completeFilePath = "c:/temp2/" + fileName;
        try
        {
            //Save the file
            File file = new File(completeFilePath);
              
            if (!file.exists()) 
            {
                file.createNewFile();
            }
      
            FileOutputStream fos = new FileOutputStream(file);
      
            fos.write(form.getFileData());
            fos.flush();
            fos.close();
        } 
        catch (IOException e)
        {
            e.printStackTrace();
        }
        //Build a response to return
        */
    	
        return Response.status(200)
            .entity("uploadFile is called, Uploaded file name : " + fileName).build();
        
    	
    }
    
    
}